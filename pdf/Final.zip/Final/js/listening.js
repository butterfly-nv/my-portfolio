document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('testForm').addEventListener('submit', function(event) {
        event.preventDefault();
        let totalScore = 0;
        const correctAnswers = {
            q1: 'with the coffee cup',
            q2: 'the drums',
            q3: 'at 2:45',
            q4: 'The Fields',
            q5: 'help the woman'
        };

        for (let i = 1; i <= 5; i++) {
            const selectedOption = document.querySelector(`input[name="q${i}"]:checked`);
            if (selectedOption) {
                if (selectedOption.value === correctAnswers[`q${i}`]) {
                    totalScore += 5;
                }
            } else {
                alert('Please answer all questions before submitting.');
                return;
            }
        }

        localStorage.setItem('listeningScore', totalScore);
        window.location.href = 'reading.html'; // Redirect to Part 3
    });
});