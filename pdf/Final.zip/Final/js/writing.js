// Timer functionality
let time = 40 * 60; // 40 minutes in seconds
const timerDisplay = document.getElementById('timer');

function updateTimer() {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    time--;
    if (time < 0) {
        clearInterval(timerInterval);
        alert('Time is up! Please submit your answers.');
        document.getElementById('submitBtn').disabled = true;
    }
}

const timerInterval = setInterval(updateTimer, 1000);

// Word count functionality
function updateWordCount(textareaId, countId) {
    const textarea = document.getElementById(textareaId);
    const countDisplay = document.getElementById(countId);
    const text = textarea.value.trim();
    const wordCount = text === '' ? 0 : text.split(/\s+/).length;
    countDisplay.textContent = `Words: ${wordCount}`;
}

document.getElementById('q1').addEventListener('input', () => updateWordCount('q1', 'wordCount1'));
// Add more event listeners for other textareas

// Submit functionality
document.getElementById('submitBtn').addEventListener('click', function() {
    // Assuming a fixed score for simplicity
    const writingScore = 10; // Replace with actual scoring logic

    // Store data in localStorage
    localStorage.setItem('writingScore', writingScore);

    // Redirect to next part
    window.location.href = 'speaking.html';
});