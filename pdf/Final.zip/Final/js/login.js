document.addEventListener('DOMContentLoaded', () => {
    const loginSection = document.getElementById('login-section');
    const registerSection = document.getElementById('register-section');

    const showRegister = document.getElementById('show-register');
    const showLogin = document.getElementById('show-login');

    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');

    showRegister.addEventListener('click', () => {
        loginSection.classList.add('d-none');
        registerSection.classList.remove('d-none');
    });

    showLogin.addEventListener('click', () => {
        registerSection.classList.add('d-none');
        loginSection.classList.remove('d-none');
    });

    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const dob = document.getElementById('dob').value;
        const gender = document.getElementById('gender').value;
        const country = document.getElementById('country').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('registerConfirmPassword').value;

        if (password === confirmPassword) {
            const user = { 
                firstName, lastName, dob, gender, country, email, password, tests: [] 
            };
            localStorage.setItem('user', JSON.stringify(user));
            alert('Registration successful! Please login.');
            registerSection.classList.add('d-none');
            loginSection.classList.remove('d-none');
        } else {
            alert('Passwords do not match!');
        }
    });

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        const user = JSON.parse(localStorage.getItem('user'));

        if (user && user.email === email && user.password === password) {
            window.location.href = 'home.html';
        } else {
            alert('Invalid email or password!');
        }
    });

    function getPasswordStrength(password) {sa
        if (password.length < 6) return 'weak';
        if (password.length < 10) return 'medium';
        return 'strong';
    }

    document.getElementById('registerPassword').addEventListener('input', (e) => {
        const password = e.target.value;
        const strength = getPasswordStrength(password);
        const strengthElement = document.getElementById('password-strength');
        strengthElement.textContent = `Password strength: ${strength}`;
        strengthElement.className = `password-strength ${strength}`;
    });
});