document.addEventListener("DOMContentLoaded", function() {
    const name = localStorage.getItem('name');
    const course = localStorage.getItem('course');
    const proficiencyLevel = localStorage.getItem('proficiencyLevel');
    const totalScore = localStorage.getItem('totalScore');

    document.getElementById('certificateName').innerText = name || 'N/A';
    document.getElementById('certificateCourse').innerText = course || 'N/A';
    document.getElementById('certificateProficiencyLevel').innerText = proficiencyLevel || 'N/A';
    document.getElementById('certificateScore').innerText = totalScore || 'N/A';
    document.getElementById('certificateDate').innerText = new Date().toLocaleDateString();

    document.getElementById('generateButton').addEventListener('click', function() {
        document.getElementById('certificate').style.display = 'block';
    });

    document.getElementById('downloadImageButton').addEventListener('click', function() {
        const certificate = document.getElementById('certificate');
        html2canvas(certificate).then(canvas => {
            const link = document.createElement('a');
            link.href = canvas.toDataURL('image/png');
            link.download = 'certificate.png';
            link.click();
        });
    });

    document.getElementById('downloadPDFButton').addEventListener('click', function() {
        const { jsPDF } = window.jspdf;
        const certificate = document.getElementById('certificate');
        html2canvas(certificate).then(canvas => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF();
            pdf.addImage(imgData, 'PNG', 10, 10, 180, 160);
            pdf.save('certificate.pdf');
        });
    });

    document.getElementById('signatureUpload').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const signatureImg = document.getElementById('signature');
                signatureImg.src = e.target.result;
                signatureImg.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });
});