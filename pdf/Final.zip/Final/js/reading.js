document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('testForm').addEventListener('submit', function(event) {
        event.preventDefault();
        let totalScore = 0;
        const correctAnswers = {
            q1: 'Improved mental health',
            q2: 'They help to mitigate the effect',
            // Add other correct answers here
        };

        // Loop through questions and calculate score
        for (let i = 1; i <= 15; i++) {
            const selectedOption = document.querySelector(`input[name="q${i}"]:checked`);
            if (selectedOption) {
                // Determine points based on question number
                let points = (i <= 10) ? 1 : 3;
                if (selectedOption.value === correctAnswers[`q${i}`]) {
                    totalScore += points;
                }
            } else {
                alert('Please answer all questions before submitting.');
                return;
            }
        }

        // Store data in localStorage
        localStorage.setItem('readingScore', totalScore);

        // Redirect to next part
        window.location.href = 'writing.html';
    });
});