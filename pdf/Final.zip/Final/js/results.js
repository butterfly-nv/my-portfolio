const thresholds = {
    'A2': 25,
    'B1': 50,
    'B2': 75,
    'C1': 100,
    'C2': 125
};

const readingScore = parseInt(localStorage.getItem('readingScore')) || 0;
const writingScore = parseInt(localStorage.getItem('writingScore')) || 0;
const speakingScore = parseInt(localStorage.getItem('speakingScore')) || 0;
const listeningScore = parseInt(localStorage.getItem('listeningScore')) || 0;
const grammarScore = parseInt(localStorage.getItem('grammarScore')) || 0;

const totalScore = readingScore + writingScore + speakingScore + listeningScore + grammarScore;

let proficiencyLevel = '';
if (totalScore <= thresholds['A2']) {
    proficiencyLevel = 'A2 - Elementary';
} else if (totalScore <= thresholds['B1']) {
    proficiencyLevel = 'B1 - Intermediate';
} else if (totalScore <= thresholds['B2']) {
    proficiencyLevel = 'B2 - Upper Intermediate';
} else if (totalScore <= thresholds['C1']) {
    proficiencyLevel = 'C1 - Advanced';
} else {
    proficiencyLevel = 'C2 - Proficient';
}

document.getElementById('readingScore').textContent = readingScore;
document.getElementById('writingScore').textContent = writingScore;
document.getElementById('speakingScore').textContent = speakingScore;
document.getElementById('listeningScore').textContent = listeningScore;
document.getElementById('grammarScore').textContent = grammarScore;
document.getElementById('totalScore').textContent = `Score: ${totalScore}`;
document.getElementById('totalScoreDetail').textContent = totalScore;
document.getElementById('proficiencyLevel').textContent = `Your proficiency level is: ${proficiencyLevel}`;

function saveResultsToLocalStorage() {
    localStorage.setItem('totalScore', totalScore);
    localStorage.setItem('proficiencyLevel', proficiencyLevel);
}