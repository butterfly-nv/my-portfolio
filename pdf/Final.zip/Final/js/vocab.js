const correctAnswers = {
    'q1': 'What',
    'q2': 'have',
    'q3': 'don’t understand',
    'q4': 'Are there',
    'q5': 'there is',
    'q6': 'Would you like',
    'q7': 'Some',
    'q8': 'Can you wait',
    'q9': 'do not have',
    'q10': 'don’t usually have',
    'q11': 'came',
    'q12': 'are you working',
    'q13': 'am studying',
    'q14': 'Do you have',
    'q15': 'worked',
    'q16': 'How long',
    'q17': 'from - to',
    'q18': 'Did',
    'q19': 'used to work',
    'q20': 'doing',
    'q21': 'work',
    'q22': 'have you ever worked',
    'q23': 'a few',
    'q24': 'have - would',
    'q25': 'in'
};

document.getElementById('grammar-test-form').addEventListener('submit', function(event) {
    event.preventDefault();

    let score = 0;
    const totalQuestions = Object.keys(correctAnswers).length;

    for (let i = 1; i <= totalQuestions; i++) {
        const questionId = `q${i}`;
        const selectedOption = document.querySelector(`input[name="${questionId}"]:checked`);

        if (selectedOption) {
            const answer = selectedOption.value;
            if (answer === correctAnswers[questionId]) {
                score++;
            }
        }
    }

    alert(`You scored ${score} out of ${totalQuestions}`);
    window.location.href = 'listening.html'; // Redirect to Part 2

});