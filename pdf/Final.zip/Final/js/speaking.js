let time = 25 * 60; // 25 minutes in seconds
        const timerDisplay = document.getElementById('timer');
        const timer = setInterval(() => {
            let minutes = Math.floor(time / 60);
            let seconds = time % 60;
            timerDisplay.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
            if (time === 0) {
                clearInterval(timer);
                alert('Time is up!');
                // Automatically submit the form or redirect if needed
            } else {
                time--;
            }
        }, 1000);

        let mediaRecorder;
        let chunks = [];

        document.getElementById('startBtn').addEventListener('click', async function() {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);

                mediaRecorder.ondataavailable = function(event) {
                    chunks.push(event.data);
                };

                mediaRecorder.onstop = function() {
                    const blob = new Blob(chunks, { type: 'audio/wav' });
                    chunks = [];
                    const url = URL.createObjectURL(blob);
                    const audio = new Audio(url);
                    audio.play(); // Play the recording
                };

                mediaRecorder.start();
                document.getElementById('startBtn').disabled = true;
                document.getElementById('stopBtn').disabled = false;
                console.log('Recording started');
            } catch (err) {
                console.error('Error accessing audio: ', err);
                alert('Unable to access your microphone.');
            }
        });

        document.getElementById('stopBtn').addEventListener('click', function() {
            if (mediaRecorder) {
                mediaRecorder.stop();
                document.getElementById('startBtn').disabled = false;
                document.getElementById('stopBtn').disabled = true;
                console.log('Recording stopped');
            }
        });

        // Submit functionality
        document.getElementById('submitBtn').addEventListener('click', function() {
            // Assuming a fixed score for simplicity
            const speakingScore = 10; // Replace with actual scoring logic

            // Store data in localStorage
            localStorage.setItem('speakingScore', speakingScore);

            // Redirect to results page
            window.location.href = 'results.html';
        });